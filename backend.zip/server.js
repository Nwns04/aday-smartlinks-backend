const { app, server, unleashReady } = require('./src/app');
const PORT = process.env.PORT || 5000;

// Always start listening immediately:
server.listen(PORT, () => {
  console.log(`🚀 Server + Socket running on port ${PORT}`);
});

// Meanwhile initialize Unleash in background:
