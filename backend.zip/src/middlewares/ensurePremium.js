// middlewares/ensurePremium.js
module.exports = function ensurePremium(req, res, next) {
    // Assume req.user is attached from your authentication middleware
    if (req.user && req.user.isPremium) {
      next();
    } else {
      return res.status(403).json({
        message: "This feature is only available to premium users."
      });
    }
  };
  