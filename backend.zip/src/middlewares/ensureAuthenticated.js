// src/middlewares/ensureAuthenticated.js
const jwt = require('jsonwebtoken');

module.exports = function ensureAuthenticated(req, res, next) {
  const auth = req.header('Authorization') || '';
  const [scheme, token] = auth.split(' ');
  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({ message: 'Authentication required' });
  }

  try {
    // verify and decode
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    // attach a minimal user object
    req.user = { _id: payload.id, email: payload.email };
    return next();
  } catch (err) {
    console.error("JWT verification failed:", err.message);
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
};
