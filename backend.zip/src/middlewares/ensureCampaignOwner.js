// middleware/ensureCampaignOwner.js
const Campaign = require("../models/Campaign");
module.exports = async function ensureCampaignOwner(req, res, next) {
  const c = await Campaign.findById(req.params.id || req.params.slug);
  if (!c) return res.status(404).json({ message: "Not found" });
  if (c.user.toString() !== req.user._id.toString()) {
    return res.status(403).json({ message: "Forbidden" });
  }
  next();
};
