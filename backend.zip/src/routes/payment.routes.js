const express = require("express");
const axios = require("axios");
const router = express.Router();
const User = require("../models/User");

const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY;
const FRONTEND_URL = process.env.FRONTEND_URL; // e.g., https://yourfrontend.com

// POST /payment/initiate
// Expected payload: { email: string, plan: "premium" }
router.post("/initiate", async (req, res) => {
  try {
    const { email, plan } = req.body;
    if (!email || plan !== "premium") {
      return res.status(400).json({ message: "Invalid payment parameters" });
    }

    // For Premium, set the amount in kobo (for NGN). For example, 1900 NGN = 1900*100 kobo.
    const amount = 1900 * 100;

    // Optional: You can include custom metadata. Here we pass the user email to later identify the transaction.
    const metadata = {
      custom_fields: [
        {
          display_name: "user_email",
          variable_name: "user_email",
          value: email,
        },
      ],
    };

    const initResponse = await axios.post(
      "https://api.paystack.co/transaction/initialize",
      {
        email,
        amount,
        // If you have pre-defined a plan in Paystack, you can include it:
        // plan: process.env.PAYSTACK_PLAN_ID,
        callback_url: `${FRONTEND_URL}/payment/verify`, // User is redirected back here after payment
        metadata,
      },
      {
        headers: {
          Authorization: `Bearer ${PAYSTACK_SECRET_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    const { authorization_url } = initResponse.data.data;
    return res.json({ authorization_url });
  } catch (error) {
    console.error("Error initiating payment:", error.response?.data || error.message);
    return res.status(500).json({ message: "Payment initiation failed" });
  }
});

// POST /payment/webhook
// This endpoint will be hit by Paystack when a transaction event occurs.
router.post("/webhook", async (req, res) => {
    try {
      const event = req.body;
      console.log("Received Paystack event:", event.event);
  
      if (event.event === "charge.success") {
        const reference = event.data.reference;
  
        // 1. Verify transaction with Paystack
        const verifyRes = await axios.get(
          `https://api.paystack.co/transaction/verify/${reference}`,
          {
            headers: {
              Authorization: `Bearer ${PAYSTACK_SECRET_KEY}`,
            },
          }
        );
  
        const verifiedData = verifyRes.data.data;
        if (verifiedData.status === "success") {
          // 2. Extract user email from metadata
          const customField = verifiedData.metadata.custom_fields.find(
            (field) => field.variable_name === "user_email"
          );
          const userEmail = customField?.value;
          if (userEmail) {
            // 3. Upgrade user to Premium
            const user = await User.findOne({ email: userEmail });
            if (user) {
              user.isPremium = true;
              user.subscriptionPlan = "premium";
              user.trialExpiresAt = null;
              await user.save();
              console.log(`User ${user.email} upgraded to Premium`);
            } else {
              console.warn(`Webhook: no user found for email ${userEmail}`);
            }
          } else {
            console.warn("Webhook: user_email metadata missing");
          }
        } else {
          console.warn(`Webhook: transaction ${reference} not successful`);
        }
      }
  
      // Always respond 200 to acknowledge receipt
      res.sendStatus(200);
    } catch (error) {
      console.error("Error processing webhook:", error.response?.data || error.message);
      res.sendStatus(500);
    }
  });



module.exports = router;
