// routes/subscription.routes.js
const express = require('express');
const router = express.Router();
const User = require('../models/User');

// POST /subscribe/essential
router.post('/subscribe/essential', async (req, res) => {
  const { email } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(404).json({ message: 'User not found' });

  user.subscriptionPlan = 'essential';
  user.trialExpiresAt = new Date(Date.now() + 14*24*60*60*1000);
  // do **not** set user.isPremium = true here!
  await user.save();

  res.json({ message: 'Essential plan activated', trialExpiresAt: user.trialExpiresAt });
});

module.exports = router;
