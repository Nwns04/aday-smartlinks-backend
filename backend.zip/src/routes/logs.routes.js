const express = require("express");
const router = express.Router();
const ActivityLog = require("../models/ActivityLog");
const ensureAuthenticated = require('../middlewares/ensureAuthenticated');

// GET /logs/:campaignId
router.get("/:campaignId", ensureAuthenticated, async (req, res) => {
  const logs = await ActivityLog.find({ campaignId: req.params.campaignId }).populate("userId", "name");
  res.json(logs);
});

// POST /logs/:campaignId
router.post("/:campaignId", ensureAuthenticated, async (req, res) => {
  const newLog = new ActivityLog({
    campaignId: req.params.campaignId,
    userId: req.user._id,
    message: req.body.message,
  });

  await newLog.save();
  res.status(201).json(newLog);
});

module.exports = router;
