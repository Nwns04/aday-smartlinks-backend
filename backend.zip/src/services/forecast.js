// services/forecast.js
const Click = require('../models/Click');
const HoltWinters = require('holt-winters');

async function getForecastData(slug, days = 14) {
  // 1) pull the last `days` of daily click counts
  const since = new Date();
  since.setDate(since.getDate() - days);
  const pipeline = [
    { $match: { slug, timestamp: { $gte: since } } },
    {
      $group: {
        _id: {
          $dateToString: { format: "%Y-%m-%d", date: "$timestamp" }
        },
        count: { $sum: 1 }
      }
    },
    { $sort: { _id: 1 } }
  ];
  const results = await Click.aggregate(pipeline);

  // 2) fill in missing dates with zero counts
  const dateMap = {};
  results.forEach(r => dateMap[r._id] = r.count);
  const data = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0,10);
    data.push({ date: key, actual: dateMap[key] || 0 });
  }

  // 3) run Holt–Winters (additive seasonality of 7 days)
  const values = data.map(d => d.actual);
  const hw = new HoltWinters({
    data: values,
    windowSize: 7,
    alpha: 0.5,
    beta: 0.4,
    gamma: 0.3,
    seasonLength: 7
  });
  const forecast = hw.predict(days);

  // 4) attach forecasted values
  return data.map((d, i) => ({
    date: d.date,
    actual: d.actual,
    forecast: Math.round(forecast[i])
  }));
}

module.exports = { getForecastData };
