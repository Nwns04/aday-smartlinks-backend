const mongoose = require('mongoose');

const ActivityLogSchema = new mongoose.Schema({
  workspace:   { type: mongoose.Schema.Types.ObjectId, ref: 'Workspace' },
  campaignId:  { type: mongoose.Schema.Types.ObjectId, ref: 'Campaign', required: true },
  user:        { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  action:      { type: String, required: true },      // e.g. "Update Campaign"
  ip:          { type: String },                      // request IP
  before:      { type: mongoose.Schema.Types.Mixed }, // snapshot pre‑change
  after:       { type: mongoose.Schema.Types.Mixed }, // snapshot post‑change
  timestamp:   { type: Date, default: Date.now },
});

module.exports = mongoose.model('ActivityLog', ActivityLogSchema);
